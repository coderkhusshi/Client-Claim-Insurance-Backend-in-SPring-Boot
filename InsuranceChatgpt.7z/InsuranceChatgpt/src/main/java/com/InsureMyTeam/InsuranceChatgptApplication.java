package com.InsureMyTeam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InsuranceChatgptApplication {

	public static void main(String[] args) {
		SpringApplication.run(InsuranceChatgptApplication.class, args);
	}

}
