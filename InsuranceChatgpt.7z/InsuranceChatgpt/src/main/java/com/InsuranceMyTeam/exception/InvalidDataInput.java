package com.InsuranceMyTeam.exception;

public class InvalidDataInput {

}
