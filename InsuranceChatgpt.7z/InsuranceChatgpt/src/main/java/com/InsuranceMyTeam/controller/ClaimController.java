package com.InsuranceMyTeam.controller;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.InsuranceMyTeam.entity.Claim;
import com.InsuranceMyTeam.service.ClaimService;

@RestController
@RequestMapping("/api/claims")
public class ClaimController {

@Autowired
private ClaimService claimService;

@GetMapping
public List<Claim> getAllClaims() {
return claimService.getAllClaims();
}

@GetMapping("/{id}")
public ResponseEntity<Optional<Claim>> getClaimById(@PathVariable Long id) {
Optional<Claim> claim = claimService.getClaimById(id);
return ResponseEntity.ok(claim);
}

@PostMapping
public ResponseEntity<Claim> createClaim(@RequestBody Claim claim) {
Claim savedClaim = claimService.createClaim(claim);
return ResponseEntity.created(URI.create("/api/claims/" + savedClaim.getId())).body(savedClaim);
}

@PutMapping("/{id}")
public ResponseEntity<Claim> updateClaim(@PathVariable Long id, @RequestBody Claim claim) {
Claim updatedClaim = claimService.updateClaim(id, claim);
return ResponseEntity.ok(updatedClaim);
}

@DeleteMapping("/{id}")
public ResponseEntity<Void> deleteClaim(@PathVariable Long id) {
claimService.deleteClaim(id);
return ResponseEntity.noContent().build();
}
}