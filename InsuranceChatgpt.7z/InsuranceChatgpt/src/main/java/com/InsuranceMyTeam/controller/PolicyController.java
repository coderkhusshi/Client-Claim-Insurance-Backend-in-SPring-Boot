package com.InsuranceMyTeam.controller;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.InsuranceMyTeam.entity.Policy;
import com.InsuranceMyTeam.service.PolicyService;

@RestController
@RequestMapping("/api/policies")
public class PolicyController {

@Autowired
private PolicyService policyService;

@GetMapping
public List<Policy> getAllPolicies() {
return policyService.getAllInsurancePolicies();
}

@GetMapping("/{id}")
public ResponseEntity<Policy> getPolicyById(@PathVariable Long id) {
Policy policy = policyService.getInsurancePolicyById(id);
return ResponseEntity.ok(policy);
}

@PostMapping
public ResponseEntity<Policy> createPolicy(@RequestBody Policy policy) {
Policy savedPolicy = policyService.createInsurancePolicy(policy);
return ResponseEntity.created(URI.create("/api/policies/" + savedPolicy.getId())).body(savedPolicy);
}

@PutMapping("/{id}")
public ResponseEntity<Policy> updatePolicy(@PathVariable Long id, @RequestBody Policy policy) {
Policy updatedPolicy = policyService.updateInsurancePolicy(id, policy);
return ResponseEntity.ok(updatedPolicy);
}

@DeleteMapping("/{id}")
public ResponseEntity<Void> deletePolicy(@PathVariable Long id) {
policyService.deleteInsurancePolicy(id);
return ResponseEntity.noContent().build();
}
}