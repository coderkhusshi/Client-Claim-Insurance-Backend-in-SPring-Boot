package com.InsuranceMyTeam.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "claim")
public class Claim {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "claim_number")
    private String claimNumber;

    private String description;

    @Column(name = "claim_date")
    private LocalDate claimDate;

    @Column(name = "claim_status")
    private String claimStatus;

    @ManyToOne
    @JoinColumn(name = "policy_id")
    private Policy insurancePolicy;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public LocalDate getClaimDate() {
		return claimDate;
	}

	public void setClaimDate(LocalDate claimDate) {
		this.claimDate = claimDate;
	}

	public String getClaimStatus() {
		return claimStatus;
	}

	public void setClaimStatus(String claimStatus) {
		this.claimStatus = claimStatus;
	}

	public Policy getInsurancePolicy() {
		return insurancePolicy;
	}

	public void setInsurancePolicy(Policy insurancePolicy) {
		this.insurancePolicy = insurancePolicy;
	}

	@Override
	public String toString() {
		return "Claim [id=" + id + ", claimNumber=" + claimNumber + ", description=" + description + ", claimStatus="
				+ claimStatus + ", insurancePolicy=" + insurancePolicy + "]";
	}

    // getters and setters
    
    
    
}
